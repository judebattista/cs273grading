/////////////////////////////////////
//	Program Name: HW01
//	Name: Jude Battista
//  Due Date: 10 Feb 2017
//  Class and Section: CS-273-1
/////////////////////////////////////

#include <iostream>
#include <string>
#include <vector>
#include "Circle.h"
#include "MyVec.h"

void Exercise01();
void Exercise02();
void Exercise03();
int* doubleCapacity(int* list, int size);
template <typename T> void Swap(T &A, T &B);

int main() {
	Exercise01();
	Exercise02();
	Exercise03();

	return 0;
}

void Exercise01() {
	std::cout << "Exercise 1: \n";
	//1: Write the C++ declaration for a pointer variable that can store the address of a double variable: 
	double* pointerToDouble;
	//2: Write a C++ statement that will use the C++ new operator to dynamicallyallocate memory for a double variable. 
	//Store the address of this newly allocated double in the pointer variable you declared in the previous step. 
	pointerToDouble = new double;
	//3: Write a C++ statement that will assign the double value 4.12 to the memory for the double variable that you allocated
	*pointerToDouble = 4.12;
	std::cout << "Value pointed to: " << *pointerToDouble << '\n';
	//4: Write a C++ statement that will release the memory that was allocated using the new operator
	delete pointerToDouble;
	pointerToDouble = nullptr;
	//5: What is wrong with the following code?
	//char* variable;
	//variable = 3;
	/*
		- Memory is never allocated for the value 3;
		- Pointer needs to be dereferenced before attempting to assign the value three to the indicated memory location
		- (Possible) Storing 3 in a char means we get the ASCII character represented by the value 3
			rather than the character '3'.
	*/
	//6. What operator would you use to obtain the memory address of the variable myVar?
	/*
		The reference operator, &
	*/
	
	//7. Declare and allocate an array of 10 int elements using dynamic memory allocation
	int* tenIntegers = nullptr;
	tenIntegers = new int[10];

	//8. Write a C++ for loop that assigns the interger value 42 to every element in the array allocated in the previous question.
	//	You must use pointer arithmetic to advance and access each element
	for (int ndx = 0; ndx < 10; ndx++) {
		*(tenIntegers + ndx) = 42;
	}

	std::cout << "tenIntegers: ";
	for (int ndx = 0; ndx < 10; ndx++) {
		std::cout << *(tenIntegers + ndx) << " ";
	}
	std::cout << '\n';

	//9. Write a statement that will release the memory allocated for the array in question 7.
	delete tenIntegers;

	//10. Write the code for a function to doulbe the size of an array
	/*
		See int doubleCapacity(int* list, int size)
	*/
	int* expandableArray = nullptr;
	expandableArray = new int[10];
	
	for (int ndx = 0; ndx < 10; ndx++) {
		*(expandableArray + ndx) = ndx;
	}

	std::cout << "initial array: ";
	for (int ndx = 0; ndx < 10; ndx++) {
		std::cout << *(expandableArray + ndx) << " ";
	}
	std::cout << '\n';
	
	expandableArray = doubleCapacity(expandableArray, 10);
	expandableArray[10] = 13;

	std::cout << "expanded array: ";
	for (int ndx = 0; ndx < 20; ndx++) {
		std::cout << *(expandableArray + ndx) << " ";
	}
	std::cout << '\n';
	//Note that the values in the array expansion are not initialized automatically.
	//May be a future requirement.

	delete expandableArray;
};

void Exercise02() {
	std::cout << "Exercise 2: \n";
	//1. Declare a class called Circle
	/*
		See Circle.h
	*/
	//2. Declare myCircle1 using the default constructor
	Circle myCircle1 = Circle();
	std::cout << "myCircle1's radius is: " << myCircle1.Radius() << '\n';

	//3. Declare myCircle2 using the overloaded constructor with a radius of 10
	Circle myCircle2 = Circle(10);
	std::cout << "myCircle2's radius is: " << myCircle2.Radius() << '\n';

	//4. Declare a pointer to a Circle and allocate memory for it using the overloaded constructor
	//to initialize its radius to 12.
	Circle* myCirclePtr = new Circle(12);
	std::cout << "myCirclePtr's radius is: " << myCirclePtr->Radius() << '\n';

	//5. Declare an array of 10 Circle objects using the default constructor
	Circle* myCircleArray = new Circle[10];

	//6. Write a C++ for loop that assigns the radius of every Circle in the array to 15
	for (int ndx = 0; ndx < 10; ndx++) {
		(myCircleArray + ndx)->Radius(15);
	}
	std::cout << "myCircleArray's radii are: ";
	for (int ndx = 0; ndx < 10; ndx++) {
		std::cout << (myCircleArray + ndx)->Radius() << " ";
	}
	std::cout << '\n';

}

void Exercise03() {
	std::cout << "Exercise 3: \n";
	//1. Using templates, convert the following Swap function to work with arguments of any generic type T
	/*
		see template <typename T> void Swap(T &A, T &B)
	*/
	int firstInt = 5;
	int secondInt = 16;
	std::cout << "First integer: " << firstInt << ". Second integer: " << secondInt << '\n';
	std::cout << "Swapping...\n";
	Swap(firstInt, secondInt);
	std::cout << "First integer: " << firstInt << ". Second integer: " << secondInt << '\n';

	std::string firstString = "foo";
	std::string secondString = "bar";
	std::cout << "First string: " << firstString << ". Second string: " << secondString << '\n';
	std::cout << "Swapping...\n";
	Swap(firstString, secondString);
	std::cout << "First string: " << firstString << ". Second string: " << secondString << '\n';

	//2. Using templates convert the following class to hold an array of any generic type T
	/*
		See MyVec.h
	*/

	//3. Declare an object of the template class to hold an array of double data types;
	MyVec<double> customDoubleVector2 = MyVec<double>(10);

	//4. Declare an STL vector for storing chars
	std::vector<char> charVector;

	//5. Use a for loop to assign a value to every element in the vector object
	charVector.resize(10);
	for (int ndx = 0; ndx < charVector.size(); ndx++) {
		charVector[ndx] = 'q';
	}

	std::cout << "charVector: ";
	for (int ndx = 0; ndx < charVector.size(); ndx++) {
		std::cout << charVector[ndx] << " ";
	}
	std::cout << '\n';

	//6. What STL vector method do you use to get the current size of the vector?
	//as seen above, we can use vector::size() to determine the number of 
	//objects in a vector

}

//Exercise 4
	//1. Draw a UML diagram describing the composition relationship between the Elevator and the Building
	/*
		See ..\..\UML.jpg
	*/

	//2. Draw a UML diagram describing the inheritance relationship between the Square and the Shape
	/*
	See ..\..\UML.jpg
	*/
	//3. When class A inherits class B, class A also inherits all public methods and variables in class B
	/*
		True
	*/
	//4. When class A inherits class B, can the private members of class B be accessed in class A?
	/*
		No
	*/
	//5. Write C++ code for the classes Animal, Cat, and Mouth
	/*
		See ..\..\ineritance
	*/
	//6. Overload our Circle's + operator
	/*
		See ..\..\operator
	*/
//

int* doubleCapacity(int *list, int size) {
	const int newSize = size * 2;
	int* listCopy = new int[newSize];
	for (int ndx = 0; ndx < size; ndx++) {
		listCopy[ndx] = list[ndx];
	}
	delete list;
	return listCopy;
}


template <typename T> void Swap(T &A, T &B) {
	T tmp = A;
	A = B;
	B = tmp;
}