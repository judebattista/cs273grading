#include "Circle.h"

//Find the area of the circle
double Circle::GetArea() {
	return radius * radius * PI;
}

//Get Radius
double Circle::Radius() {
	return radius;
}

//Set Radius
void Circle::Radius(double radius) {
	this->radius = radius;
}