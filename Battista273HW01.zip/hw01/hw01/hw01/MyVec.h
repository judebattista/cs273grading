#pragma once

template <class T> class MyVec {

private:     
	T *array;  // dynamically allocated array  
public:     
	MyVec(int size) { // constructor creates array of size �size�         
		array = new T[size];     
	}     
	~MyVec() {  // destructor returns memory back to system         
		delete [] array;     
	}
};