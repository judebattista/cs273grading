#ifndef _CIRCLE_H
#define _CIRCLE_H
class Circle {
private:
	const double PI = 3.1415926535897932384626433832795028841971693993751;
	double radius;

public:
	Circle() {
		this->radius = 0;
	}
	Circle(double radius) {
		this->radius = radius;
	}
	double GetArea();
	double Radius();
	void Radius(double radius);
};

#endif //_CIRCLE_H
