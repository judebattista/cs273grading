/////////////////////////////////////
//	Program Name: HW01 Inheritance
//	Name: Jude Battista
//  Date: 10 Feb 2017
//  Class and Section: CS-273-1
/////////////////////////////////////

#include "Cat.h"

int main()
{
	Cat myCat;

}