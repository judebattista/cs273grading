#ifndef _ANIMAL_H
#define _ANIMAL_H

class Animal {

};

#endif // !_ANIMAL_H

