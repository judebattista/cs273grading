#ifndef _MOUTH_H
#define _MOUTH_H

class Mouth {

};

#endif // !_MOUTH_H
