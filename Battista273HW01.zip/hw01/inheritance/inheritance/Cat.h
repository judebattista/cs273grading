#ifndef _CAT_H
#define _CAT_H

#include "Animal.h"
#include "Mouth.h"

class Cat : public Animal {
private:
	Mouth mouth;
};

#endif // !_CAT_H
