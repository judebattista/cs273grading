/////////////////////////////////////
//	Program Name: HW01 - operator
//	Name: Jude Battista
//  Due Date: 10 Feb 2017
//  Class and Section: CS-273-1
/////////////////////////////////////

#include <iostream>
#include "Circle.h"

int main() {
	/*
	Circle operandOne, operandTwo, summedCircles;
	operandOne.Radius(10);
	operandTwo.Radius(7);
	summedCircles = operandOne + operandTwo;
	*/

	Circle* left = new Circle(10);
	Circle* right = new Circle(5);
	Circle sum = *left + *right;
	std::cout << "Left operand radius: " << left->Radius() << ", right operand radius: " << right->Radius() << ", ";
	std::cout << "Sum's radius: " << sum.Radius() << '\n';
	return 0;
}