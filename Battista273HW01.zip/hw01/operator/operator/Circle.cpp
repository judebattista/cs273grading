#include "Circle.h"

//Find the area of the circle
double Circle::GetArea() {
	return radius * radius * PI;
}

//Get Radius
double Circle::Radius() const {
	return radius;
}

//Set Radius
void Circle::Radius(double radius) {
	this->radius = radius;
}

//Overload operator+
Circle Circle::operator+=(const Circle& right) {
	this->Radius(this->radius + right.radius);
	return *this;
}

Circle operator+(const Circle& leftside, const Circle& rightside)
{
	Circle result;
	result.Radius(leftside.Radius() + rightside.Radius());
	return result;

}